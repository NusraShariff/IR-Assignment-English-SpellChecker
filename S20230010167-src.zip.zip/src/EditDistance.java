import java.util.*;

public class EditDistance {

    public static int calculate(String a, String b) {
        int[][] dp = new int[a.length() + 1][b.length() + 1];

        for (int i = 0; i <= a.length(); i++) dp[i][0] = i;
        for (int j = 0; j <= b.length(); j++) dp[0][j] = j;

        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                int cost = (a.charAt(i - 1) == b.charAt(j - 1)) ? 0 : 1;
                
                dp[i][j] = Math.min(
                    Math.min(dp[i - 1][j] + 1,   
                             dp[i][j - 1] + 1),   
                    dp[i - 1][j - 1] + cost   
                );

                if (i > 1 && j > 1 && a.charAt(i - 1) == b.charAt(j - 2)
                        && a.charAt(i - 2) == b.charAt(j - 1)) {
                    dp[i][j] = Math.min(dp[i][j], dp[i - 2][j - 2] + cost);
                }
            }
        }
        return dp[a.length()][b.length()];
    }

    public static List<String> getSuggestions(String word, Set<String> dict) {
        final int MAX_EDIT_DISTANCE = 2; 
        final int MAX_SUGGESTIONS = 5;   
        
        Map<String, Integer> candidates = new HashMap<>();

        for (String dictWord : dict) {
            int dist = calculate(word, dictWord);
            if (dist <= MAX_EDIT_DISTANCE) {
                candidates.put(dictWord, dist);
            }
        }

        List<Map.Entry<String, Integer>> sortedCandidates = new ArrayList<>(candidates.entrySet());
        sortedCandidates.sort(Map.Entry.comparingByValue());

        List<String> suggestions = new ArrayList<>();
        for (int i = 0; i < sortedCandidates.size() && i < MAX_SUGGESTIONS; i++) {
            suggestions.add(sortedCandidates.get(i).getKey());
        }

        return suggestions;
    }
}