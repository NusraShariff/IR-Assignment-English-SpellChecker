import java.io.*;
import java.nio.charset.StandardCharsets;

public class FileManager {
    public static void saveResult(String text, String filePath) {
        try (Writer writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(filePath), StandardCharsets.UTF_8))) {
            writer.write(text);
        } catch (IOException e) {
            System.out.println("error writing output: " + e.getMessage());
        }
    }
}
