import java.util.*;

public class SpellChecker {
    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in, "UTF-8");

        String dictPath = "data/english_dictionary.txt";
        System.out.println("Loading English dictionary...");

        Set<String> dict = DictionaryBuilder.loadDictionary(dictPath);
        if (dict.isEmpty()) {
            System.out.println("Dictionary could not be loaded. Please check the path: " + dictPath);
            return;
        }
        System.out.println("Dictionary loaded with " + dict.size() + " words.");

        System.out.println("\nEnter a sentence (or 'q' to quit):");
        String sentence = sc.nextLine().trim();

        while (!sentence.equalsIgnoreCase("q")) {
            String[] words = sentence.split("\\s+"); // Split by one or more spaces
            StringBuilder result = new StringBuilder();
            boolean mistakesFound = false;

            for (String w : words) {
                String cleanWord = w.replaceAll("[^a-zA-Z]", "").toLowerCase();
                
                if (cleanWord.isEmpty()) continue; 

                if (!dict.contains(cleanWord)) {
                    mistakesFound = true;
                    System.out.println("Misspelled word: " + w + " (checking as: " + cleanWord + ")");
                    List<String> suggestions = EditDistance.getSuggestions(cleanWord, dict);
                    
                    System.out.println("Suggestions: " + suggestions);
                    result.append("Misspelled: ").append(w)
                          .append(" → Suggestions: ").append(suggestions).append("\n");
                }
            }

            if (!mistakesFound) {
                result.append("No spelling mistakes found.\n");
                System.out.println("No spelling mistakes found.");
            }

            String outputFilePath = "output/english_spell_check_results.txt";
            FileManager.saveResult(result.toString(), outputFilePath);
            System.out.println("Results saved to " + outputFilePath);
            
            System.out.println("\nEnter a sentence (or 'q' to quit):");
            sentence = sc.nextLine().trim();
        }
        
        System.out.println("Goodbye!");
        sc.close();
    }
}