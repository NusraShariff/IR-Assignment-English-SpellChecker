import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class DictionaryBuilder {
    public static Set<String> loadDictionary(String filePath) {
        Set<String> dictionary = new HashSet<>();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                line = line.trim().toLowerCase();
                if (!line.isEmpty()) {
                    dictionary.add(line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading dictionary: " + e.getMessage());
        }
        return dictionary;
    }
}
